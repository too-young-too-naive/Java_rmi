/** Conformance tests for the RMI library. */
package conformance.rmi;
