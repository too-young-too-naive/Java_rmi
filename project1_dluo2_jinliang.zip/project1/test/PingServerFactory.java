package test;

public class PingServerFactory {
    public static PingServerImpl makePingServer() {
        return new PingServerImpl();
    }
}
